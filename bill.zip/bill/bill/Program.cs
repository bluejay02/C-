﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace bill
{
    class Program
    {
        static void Main(string[] args)
        {
            int custid, conu;
            double chg, surchg = 0, gramt, netamt;
            string connm;

            Console.Write("Input Customer ID :");
            custid = Convert.ToInt32(Console.ReadLine());

            Console.Write("Input the name of the customer :");
            connm = Console.ReadLine();

            Console.Write("Input the unit consumed by the customer : ");
            conu = Convert.ToInt32(Console.ReadLine());

            if (conu < 200)
                chg = 1.20;
            else if (conu >= 200 && conu < 400)
                chg = 1.50;
            else if (conu >= 400 && conu < 600)
                chg = 1.80;
            else
                chg = 2.00;
            gramt = conu * chg;
            if (gramt > 300)
                surchg = gramt * 15 / 100.0;
            netamt = gramt + surchg;
            if (netamt < 100)
                netamt = 100;
            Console.Write("Electricity Bill\n");
            Console.WriteLine("Customer IDNO                       :" + custid);
            Console.WriteLine("Customer Name                       :" + connm);
            Console.WriteLine("unit Consumed                       :" + conu);
            Console.WriteLine("Amount Charges @Rs.  per unit :" + (chg + gramt));
            Console.WriteLine("Surchage Amount                     :" + surchg);
            Console.WriteLine("Net Amount Paid By the Customer     :" + netamt);
            Console.Read();
        }
    }
}
