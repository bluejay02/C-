﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace marksheet
{
    public partial class Marksheet : Form
    {
        public static int id;
        public static string name;

        DataTable dt = new DataTable();

        public Marksheet()
        {
            InitializeComponent();
        }

        private void Marksheet_Load(object sender, EventArgs e)
        {
            textBox1.Text = "" + Marksheet.id;
            textBox3.Text = "" + Marksheet.name;

            if (textBox1.Text == "Marksheet.id" || textBox3.Text == "Marksheet.name")
            {
                string mark = "select studid,sub1,sub2,sub3,sub4,total,percentage,result,grade from marksheet where studid='" + textBox2.Text + "' and sub1='" + textBox7.Text + "' and sub2='" + textBox8.Text + "' and sub3='" + textBox9.Text + "' and sub4='" + textBox10.Text + "' and total='" + textBox11.Text + "' and percentage='" + textBox12.Text + "' and result='" + textBox13.Text + "' and grade='" + textBox14.Text + "' ";
                string stud = "select stream,sem,class from Stud where stream='" + textBox4 + "' and sem='" + textBox5.Text + "' and class='" + textBox6.Text + "' ";
                SqlDataAdapter da = new SqlDataAdapter(mark, A.scn);
                SqlDataAdapter dad = new SqlDataAdapter(stud, A.scn);

                da.Fill(dt);
                dad.Fill(dt);
            }
            else
            {
                MessageBox.Show("Try Again");
            }
        }
    }
}
