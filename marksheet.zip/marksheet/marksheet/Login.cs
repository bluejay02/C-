﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace marksheet
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            string log = "select id,name from stud where id='" + textBox1.Text + "' AND name='" + textBox2.Text + "' ";
            SqlDataAdapter da = new SqlDataAdapter(log,A.scn);
            DataTable dt = new DataTable();
            int a = da.Fill(dt);

            if (dt.Rows.Count == 1)
            {
                Marksheet.id = Convert.ToInt32(dt.Rows[0]["id"].ToString());
                Marksheet.name = dt.Rows[0]["name"].ToString();

                MessageBox.Show("login Sucssecefully", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();
                new Marksheet().Show();
            }
        }
    }
}
