﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace marksheet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string submit = "insert into stud values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + comboBox1.Text + "','" + comboBox2.Text +"','" + comboBox3.Text + "')";
            SqlDataAdapter sda = new SqlDataAdapter(submit,A.scn);
            DataTable dt = new DataTable();
            int a = sda.Fill(dt);

            if (a >= 0)
            {
                MessageBox.Show("Your Data Submited Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cancle();
                this.Hide();
                Login L = new Login();
                L.Show();
            }
            else
            {
                MessageBox.Show("Something Is Worng!!!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cancle();
            }
        }

        private void cancle()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
            textBox2.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cancle();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login L = new Login();
            L.Show();
        }

    }
}
