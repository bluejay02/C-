﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace conn
{
    public partial class Home : Form
    {
        int currentrecord = 0;
        int totalrecord = 0;
        DataTable dt = new DataTable();

        public Home()
        {
            InitializeComponent();
        }

        //display function
        private void disp()
        {
            string disp = "select * from datatbl";
            SqlDataAdapter da = new SqlDataAdapter(disp,Class1.cn);
            int a = da.Fill(dt);

            totalrecord = dt.Rows.Count;
            navigate();
        }

        //navigation function
        private void navigate()
        {
            textBox1.Text = dt.Rows[currentrecord]["usernm"].ToString();
            textBox2.Text = dt.Rows[currentrecord]["password"].ToString();
        }

        //logout button
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Form1().Show();
        }

        //data grid view
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string datagrid = "select * from datatbl";
            SqlDataAdapter da = new SqlDataAdapter(datagrid,Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count == 0)
            {
                dataGridView1.DataSource = dt;
            }
        }

        //hide form closed
        private void Home_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        //update button
        private void button2_Click(object sender, EventArgs e)
        {
            string update = "update datatbl set usernm='"+textBox1.Text+"',password='"+textBox2.Text+"' where usernm='"+textBox1.Text+"' ";
            SqlDataAdapter da = new SqlDataAdapter(update, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            MessageBox.Show("Record Updated!!", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        //delete button 
        private void button5_Click(object sender, EventArgs e)
        {
            string delete = "delete from datatbl where usernm='"+textBox1.Text+"' and password='"+textBox2.Text+"' ";
            SqlDataAdapter da = new SqlDataAdapter(delete,Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            MessageBox.Show("Record Deleted!!","DataBase",MessageBoxButtons.OK,MessageBoxIcon.Warning);
        }

        //clear text in textboxs
        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Already Text is Clear!!", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                textBox1.Text = "";
                textBox2.Text = "";
                textBox1.Focus();
            }
        }

        //home load
        private void Home_Load(object sender, EventArgs e)
        {
            string sql = "select * from datatbl";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            totalrecord = dt.Rows.Count;

            dataGridView1.DataSource = dt;
            comboBox1.DataSource = dt;
            navigate();
        }

        //add key
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        //combobox use to show data-table rows number
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string combo = "select * from datatbl";
            SqlDataAdapter da = new SqlDataAdapter(combo,Class1.cn);
            DataTable dt = new DataTable();
            
            int a = da.Fill(dt);

            if (dt.Rows.Count == 1)
            {
                MessageBox.Show(ToString());
            }
        }

        //clear text
        private void cancle()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox1.Focus();
        }

        //first button
        private void button4_Click(object sender, EventArgs e)
        {
            currentrecord = 0;
            navigate();
        }

        //last button
        private void button6_Click(object sender, EventArgs e)
        {
            currentrecord = totalrecord - 1;
            navigate();
        }

        //previous button
        private void button8_Click(object sender, EventArgs e)
        {
            if (currentrecord > 0)
            {
                currentrecord--;
                navigate();
            }
            else if (currentrecord == 0)
            {
                currentrecord = totalrecord - 1;
                navigate();
            }
        }

        //last button
        private void button7_Click(object sender, EventArgs e)
        {
            if (currentrecord < totalrecord - 1)
            {
                currentrecord++;
                navigate();
            }
            else if (currentrecord == totalrecord - 1)
            {
                currentrecord = 0;
                navigate();
            }
        }


    }
}
