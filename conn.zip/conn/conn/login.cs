﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace conn
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        //login button
        private void button2_Click(object sender, EventArgs e)
        {
             if (textBox1.Text != "" || textBox2.Text != "")
             {
                string sql = "select usernm,password from datatbl where usernm='"+textBox1.Text+"' AND password='"+textBox2.Text+"' ";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();
                int a = da.Fill(dt);

                if (dt.Rows.Count==1)
                {
                    MessageBox.Show("login Sucssecefully", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cancle();
                    this.Hide();
                    new Home().Show();
                }
                else
                {
                    MessageBox.Show("Something Wrong! Try Again...", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cancle();
                }
            }
            else
            {
                MessageBox.Show("Please Enter The Value!!!","DataBase",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                 cancle();
            }
        }

        //clear text
        private void cancle()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox1.Focus();
        }

        //cancle button
        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Already Text is Clear!!","DataBase",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }
            else
            {
                textBox1.Text = "";
                textBox2.Text = "";
                textBox1.Focus();
            }
        }

        //signup form
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Form1().Show();
        }

        //forgate password button
        private void button4_Click(object sender, EventArgs e)
        {
           
        }

        //hide form close
        private void login_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
